welcome_mess,goodluck_mess = 'Welcome to SVATTT Quals 2017', 'Try hard and good luck for next time !!!'
FLAG = 'SVATTT{D3s_Ciph3r_izz_t00_eaZy_Right????}'
